/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                             (c) Copyright 2003, Micrium, Inc., Weston, FL
*                         (c) Copyright 2003, JIDEC Consultants, Sherbrooke, QC
*                                          All Rights Reserved
*
*                                             Cogent CSB337
*                                              Sample code
* File         : APP.C
* Originally by: Jean J. Labrosse
* Modified by  : Christian Legare
* Modified by  : Jean-Denis Hatier
*
*********************************************************************************************************
*/

#include <includes.h>

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/

#define  TASK_START_APP_PRIO    10
#define  TASK_APP_1_PRIO        15
#define  TASK_APP_2_PRIO        20
#define  TASK_STK_SIZE        2048

/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/

        OS_STK  AppStartTaskStk[TASK_STK_SIZE];
        OS_STK  AppTask1Stk[TASK_STK_SIZE];
        OS_STK  AppTask2Stk[TASK_STK_SIZE];

static  INT16U  AppTask1LedStatus;
static  INT16U  AppTask2LedStatus;

static  INT16U  Switch0Pressed;
static  INT16U  TaskSelected;

/*
*********************************************************************************************************
*                                          FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void  AppStartTask(void *p_arg);
static  void  AppTask1(void *p_arg);
static  void  AppTask2(void *p_arg);

/*
*********************************************************************************************************
*                                             C ENTRY POINT
*********************************************************************************************************
*/

int  main (void)
{
    INT8U err;

    BSP_Init();                                 /* Initialize CSB337 BSP                               */

    mon_printf("\r\nInitialize uC/OS-II...");
    OSInit();                                   /* Initialize uC/OS-II                                 */

                                                /* Create start task                                   */
    OSTaskCreateExt(AppStartTask,
                    NULL,
                    (OS_STK *)&AppStartTaskStk[TASK_STK_SIZE - 1],
                    TASK_START_APP_PRIO,
                    TASK_START_APP_PRIO,
                    (OS_STK *)&AppStartTaskStk[0],
                    TASK_STK_SIZE,
                    NULL,
                    OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR);

                                                /* Give a name to tasks                                */
#if OS_TASK_NAME_SIZE > 10
    OSTaskNameSet(OS_IDLE_PRIO,        "Idle task",  &err);
    OSTaskNameSet(OS_STAT_PRIO,        "Stat task",  &err);
    OSTaskNameSet(TASK_START_APP_PRIO, "Start task", &err);
#endif

    mon_printf("\r\nStart uC/OS-II...");
    OSStart();                                  /* Start uC/OS-II                                      */
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                              STARTUP TASK
*
* Description : This is an example of a startup task.  As mentioned in the book's text, you MUST
*               initialize the ticker only once multitasking has started.
* Arguments   : p_arg is the argument passed to 'AppStartTask()' by 'OSTaskCreate()'.
* Notes       : 1) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                  used.  The compiler should not generate any code for this statement.
*               2) Interrupts are enabled once the task start because the I-bit of the CCR register was
*                  set to 0 by 'OSTaskCreate()'.
*********************************************************************************************************
*/

static void  AppStartTask (void *p_arg)
{
    p_arg = p_arg;                              /* Prevent compiler warning                            */

    mon_printf("\r\nStart timer tick...");
    Tmr_TickInit();                             /* Start timer tick                                    */

#if OS_TASK_STAT_EN > 0
    mon_printf("\r\nStart statistics...");
    OSStatInit();                               /* Start stats task                                    */
#endif    

    OSTaskCreate(AppTask1, (void *)0, (void *)&AppTask1Stk[TASK_STK_SIZE], TASK_APP_1_PRIO);
    OSTaskCreate(AppTask2, (void *)0, (void *)&AppTask2Stk[TASK_STK_SIZE], TASK_APP_2_PRIO);

    mon_printf("\r\nStarting uC/OS-II demo...\n");
    mon_printf("Press user switch 0 to toggle between the two tasks\n");
    mon_printf("Task 1 : Green LED\n");

    AppTask1LedStatus = 1;
    AppTask2LedStatus = 0;
    Switch0Pressed = 0;
    TaskSelected = 1;

    while (TRUE) {                              /* Task body, always written as an infinite loop.      */
        if (GetPushButtonStatus(1)) {           /* Switch pressed                                      */
            if (Switch0Pressed == 0) {
                Switch0Pressed = 1;             /* Record switch change of status                      */
                switch (TaskSelected) {
                    case 1:
                         TaskSelected = 2;
                         LED_Off(2);            /* Turn off  LED 1                                     */
                         mon_printf("Task 2 : Yellow LED\n");
                         break;

                   case 2:
                         TaskSelected = 1;
                         LED_Off(3);            /* Turn off  LED 2                                     */
                         mon_printf("Task 1 : Green LED\n");
                         break;
                }
            }
        }
        else {                                  /* Switch unpressed                                    */
            if (Switch0Pressed == 1) {
                Switch0Pressed = 0;             /* Record switch change of status                      */
            }
        }

                                                /* Delay task execution for 250 ms                     */
        OSTimeDly(250 * OS_TICKS_PER_SEC / 1000);
    }
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                                TASK #1
*
* Description : This is an example of a task.
* Arguments   : p_arg is the argument passed to 'AppTask1()' by 'OSTaskCreate()'.
* Notes       : 1) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                  used.  The compiler should not generate any code for this statement.
*               2) Interrupts are enabled once the task start because the I-bit of the CCR register was
*                  set to 0 by 'OSTaskCreate()'.
*               3) This Task uses the LEDs and the switch of the CSB355 board,
*                  it blinks user LED 2 on the CSB360.
*********************************************************************************************************
*/

static void  AppTask1 (void *p_arg)
{
    p_arg = p_arg;                              /* Prevent compiler warning                            */

    while (TRUE) {                              /* Task body, always written as an infinite loop.      */
        if (TaskSelected == 1) {
            switch (AppTask1LedStatus) {
            case 0:
                LED_On(2);                      /* Turn on LED 2                                       */
                AppTask1LedStatus = 1;
                break;
            case 1:
                LED_Off(2);                     /* Turn off LED 2                                      */
                AppTask1LedStatus = 0;
                break;
            }

        }
                                                /* Delay task execution for 250 ms                     */
        OSTimeDly(250 * OS_TICKS_PER_SEC / 1000);
    }
}

/*$PAGE*/
/*
*********************************************************************************************************
*                                                TASK #2
*
* Description : This is an example of a task.
* Arguments   : p_arg is the argument passed to 'AppTask2()' by 'OSTaskCreate()'.
* Notes       : 1) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                  used.  The compiler should not generate any code for this statement.
*               2) Interrupts are enabled once the task start because the I-bit of the CCR register was
*                  set to 0 by 'OSTaskCreate()'.
*               3) This Task uses the LEDs and the switch of the CSB355 board,
*                  it blinks user LED 3 on the CSB355.
*********************************************************************************************************
*/

static void  AppTask2 (void *p_arg)
{
    p_arg = p_arg;                              /* Prevent compiler warning                            */

    while (TRUE) {                              /* Task body, always written as an infinite loop.      */
        if (TaskSelected == 2) {
            switch (AppTask2LedStatus) {
            case 0:
                LED_On(3);                      /* Turn on LED 3                                       */
                AppTask2LedStatus = 1;
                break;
            case 1:
                LED_Off(3);                     /* Turn off LED 3                                      */
                AppTask2LedStatus = 0;
                break;
            }
        }
                                                /* Delay task execution for 250 ms                     */
        OSTimeDly(250 * OS_TICKS_PER_SEC / 1000);
    }
}
