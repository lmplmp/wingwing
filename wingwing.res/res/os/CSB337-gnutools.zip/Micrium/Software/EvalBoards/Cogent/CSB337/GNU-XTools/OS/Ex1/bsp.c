/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                             (c) Copyright 2003, Micrium, Inc., Weston, FL
*                         (c) Copyright 2003, JIDEC Consultants, Sherbrooke, QC
*                                          All Rights Reserved
*
*                                             Cogent CSB337
*                                         Board Support Package
*
* File         : BSP.C
* Originally by: Jean J. Labrosse
* Modified by  : Jean-Denis Hatier
*
*********************************************************************************************************
*/

#include <includes.h>

/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/

#define  vulong INT32U
#define  AT91C_ST_PITS     ((unsigned int) 0x1 <<  0)          // (ST) Period Interval Timer Interrupt
#define  AT91C_ST_IER      (*(INT32U *) 0xFFFFFD14L)           // (ST) Interrupt Enable Register
#define  AT91C_ST_PIMR     (*(INT32U *) 0xFFFFFD04L)           // (ST) Period Interval Mode Register
#define  AT91C_ST_SR       (*(INT32U *) 0xFFFFFD10L)           // (ST) Status Register

#define  AT91C_MC_RCR      (*(INT32U *) 0xFFFFFF00L)           // (MC) Remap Control Register

#define  UMON_ENTRY_POINT  (*(INT32U *) 0x10000050L)

#define  PIO_SODR              0x30
#define  PIO_CODR              0x34
#define  PIO_PDSR              0x3c

#define  BIT21             (1 << 21)
#define  BIT28             (1 << 28)
#define  BIT29             (1 << 29)

#define  AT91RM9200_CLK         328

#define  DEFAULT_STK_SIZE      2048
#define  EXCEPT_STK_SIZE       2048

/*
*********************************************************************************************************
*                                            GLOBAL VARIABLES
*********************************************************************************************************
*/

INT8U  *punDefaultStackTop;
INT8U  *punExceptStackTop;

/*
*********************************************************************************************************
*                                               PROTOTYPES
*********************************************************************************************************
*/

void  BSP_InitIntCtrl(void);
void  SetStackPointers(void);

/*
*********************************************************************************************************
*                                           BSP INITIALIZATION
*
* Description : This function should be called by your application code before you make use of any of the
*               functions found in this module.
*
* Arguments   : none
*********************************************************************************************************
*/

void  BSP_Init (void)
{
    static INT8U aunDefaultStack[DEFAULT_STK_SIZE];
    static INT8U aunExceptStack[EXCEPT_STK_SIZE];
    punDefaultStackTop     = &aunDefaultStack[DEFAULT_STK_SIZE - 1];
    punExceptStackTop      = &aunExceptStack[EXCEPT_STK_SIZE - 1];

    AIC_CTL_REG(AIC_IDCR)  = 0xFFFFFFFFL;       /* Disable ALL interrupts                              */
    AT91C_MC_RCR = 1;                           /* Remap SRAM to 0x00000000                            */

    BSP_InitIntCtrl();                          /* Initialize the interrupt controller                 */
    SetStackPointers();                         /* Initialize the default and exception stacks         */
    monConnect(UMON_ENTRY_POINT, NULL, NULL);   /* Initialize monitor services                         */
    LED_Init();                                 /* Initialize LEDs                                     */
}

/*
*********************************************************************************************************
*                                    INITIALIZE INTERRUPT CONTROLLER
*
* Description : This function should be called by your application code before you make use of any of the
*               functions found in this module.
*
* Arguments   : none
*********************************************************************************************************
*/

void  BSP_InitIntCtrl (void)
{
    AIC_CTL_REG(AIC_IDCR)  = 0xFFFFFFFFL;       /* Disable ALL interrupts                              */

                                                /* 0xE51FFF20L is opcode of (ldr pc,[pc,#-0xf20])      */
    *(INT32U *)0x00000018L = 0xE51FFF20L;       /* IRQ exception vector - install redirection to AIC   */
}

/*
*********************************************************************************************************
*                                         TICKER INITIALIZATION
*
* Description : This function is called to initialize uC/OS-II's tick source (typically a timer generating
*               interrupts every 1 to 100 mS).
*
*               We decided to use Timer #0 as the tick interrupt source.
*
* Arguments   : none
*
* Notes       :
*********************************************************************************************************
*/

void  Tmr_TickInit (void)
{
                                                /* Setup the interrupt vector for the tick ISR         */
    AIC_SVR_REG(1*4)       = (INT32U)OS_CPU_Tick_ISR;
    AIC_SMR_REG(1*4)       = 0x00000024L;       /* Timer interrupt is a medium priority                */
    AIC_CTL_REG(AIC_IECR)  = 0x00000002L;       /* Enable timer interrupt at AIC level                 */

    AT91C_ST_PIMR          = AT91RM9200_CLK;    /* Initialize the timer to generate 100 Hz             */
    AT91C_ST_IER           = AT91C_ST_PITS;     /* Enable timer interrupt at ST level                  */
}

/*
*********************************************************************************************************
*                                          TIMER #0 IRQ HANDLER
*
* Description : This function handles the timer interrupt that is used to generate TICKs for uC/OS-II.
*
* Arguments   : none
*********************************************************************************************************
*/

void  Tmr_TickHandler (void)
{
    if (AT91C_ST_SR & AT91C_ST_PITS)            /* If the interrupt is from the tick source,           */
    {
        OSTimeTick();                           /*  call OSTimeTick()                                  */
    }

    AIC_CTL_REG(AIC_EOICR) = 0xFFFFFFFFL;       /* End of interrupt handler                            */
}

/*
*********************************************************************************************************
*                                           BSP INITIALIZATION
*
* Description : This function should be called by your application code before you make use of any of the
*               functions found in this module.
*
* Arguments   : none
*********************************************************************************************************
*/

void  LED_Init (void)
{
    LED_Off(0);                                 /* Turn OFF all the LEDs                               */
}

/*
*********************************************************************************************************
*                                                 LED ON
*
* Description : This function is used to control any or all the LEDs on the board.
*
* Arguments   : led    is the number of the LED to control
*                      0    indicates that you want ALL the LEDs to be ON
*                      1    turns ON User LED 0 on the board
*                      .
*                      .
*                      3    turns ON User LED 2 on the board
*********************************************************************************************************
*/

void  LED_On (INT8U led)
{
    switch (led) {
        case 0:
             PIOB_REG(PIO_CODR) = 0x07;
             break;

        case 1:
             PIOB_REG(PIO_CODR) = 0x04;
             break;

        case 2:
             PIOB_REG(PIO_CODR) = 0x02;
             break;

        case 3:
             PIOB_REG(PIO_CODR) = 0x01;
             break;
    }
}

/*
*********************************************************************************************************
*                                                LED OFF
*
* Description : This function is used to control any or all the LEDs on the board.
*
* Arguments   : led    is the number of the LED to turn OFF
*                      0    indicates that you want ALL the LEDs to be OFF
*                      1    turns OFF User LED0 on the board
*                      .
*                      .
*                      3    turns OFF User LED2 on the board
*********************************************************************************************************
*/

void  LED_Off (INT8U led)
{
    switch (led) {
        case 0:
             PIOB_REG(PIO_SODR) = 0x07;
             break;

        case 1:
             PIOB_REG(PIO_SODR) = 0x04;
             break;

        case 2:
             PIOB_REG(PIO_SODR) = 0x02;
             break;

        case 3:
             PIOB_REG(PIO_SODR) = 0x01;
             break;
    }
}

/*
*********************************************************************************************************
*                                         GET PUSH BUTTON STATUS
*
* Description : This function is used to get the status of any push button on the board.
*
* Arguments   : pushbutton    is the number of the push button to probe
*                             1    probe the push button 0
*                             .
*                             .
*                             3    probe the push button 2
*********************************************************************************************************
*/

BOOLEAN  GetPushButtonStatus (INT8U pushbutton)
{
    BOOLEAN pbStatus = FALSE;

    switch (pushbutton) {
        case 1:
             pbStatus = ((PIOB_REG(PIO_PDSR) & BIT29) == 0);
             break;

        case 2:
             pbStatus = ((PIOB_REG(PIO_PDSR) & BIT28) == 0);
             break;

        case 3:
             pbStatus = ((PIOA_REG(PIO_PDSR) & BIT21) == 0);
             break;
    }

    return pbStatus;
}
