function mmLoadMenus() {

  window.mm_menu_1019113713_0 = new Menu("root",166,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  mm_menu_1019113713_0.addMenuItem("Alliances","location='http://www.st.com/stonline/company/projects/socot/index.htm'");
  mm_menu_1019113713_0.addMenuItem("Company&nbsp;Profile","location='http://www.st.com/stonline/company/index.htm'");
  mm_menu_1019113713_0.addMenuItem("Employment","location='http://jobs.st.com/'");
  mm_menu_1019113713_0.addMenuItem("Executive&nbsp;Officers","location='http://www.st.com/stonline/company/executiv/executiv.htm'");
  mm_menu_1019113713_0.addMenuItem("Investor&nbsp;Information","location='http://www.st.com/stonline/company/investor/index.htm'");
  mm_menu_1019113713_0.addMenuItem("Media&nbsp;&amp;&nbsp;Analyst&nbsp;Info&nbsp;Center","location='http://www.st.com/stonline/press/news/latest.htm'");
  mm_menu_1019113713_0.addMenuItem("ST&nbsp;Foundation","location='http://www.stfoundation.org'");
  mm_menu_1019113713_0.hideOnMouseOut=true;
  mm_menu_1019113713_0.childMenuIcon="images/arrows.gif";
  mm_menu_1019113713_0.menuBorder=1
  mm_menu_1019113713_0.menuLiteBgColor='#ffffff';
  mm_menu_1019113713_0.menuBorderBgColor='#555555';
  mm_menu_1019113713_0.bgColor='#000000';

  window.mm_menu_1019113855_1 = new Menu("root",178,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  mm_menu_1019113855_1.addMenuItem("Distributors&nbsp;&amp;&nbsp;Representatives","location='http://www.st.com/stonline/address/distrib/index.htm'");
  mm_menu_1019113855_1.addMenuItem("Questions&nbsp;to&nbsp;Webmaster","location='http://www.st.com/stonline/stappl/feedback/app?page=webmasterQuestion'");
  mm_menu_1019113855_1.addMenuItem("Manufacturing&nbsp;&amp;&nbsp;Design","location='http://www.st.com/stonline/address/mfg/index.htm'");
  mm_menu_1019113855_1.addMenuItem("Regional&nbsp;Warehouses","location='http://www.st.com/stonline/address/whouse/warehous.htm'");
  mm_menu_1019113855_1.addMenuItem("ST&nbsp;Sales&nbsp;Offices","location='http://www.st.com/stonline/address/offices/index.htm'");
  mm_menu_1019113855_1.addMenuItem("Worldwide&nbsp;Headquarters","location='http://www.st.com/stonline/address/headquarters/index.htm'");
  mm_menu_1019113855_1.addMenuItem("See&nbsp;All","location='http://www.st.com/stonline/domains/contact_us/contact_us_welcome.htm'");
  mm_menu_1019113855_1.hideOnMouseOut=true;
  mm_menu_1019113855_1.menuBorder=1;
  mm_menu_1019113855_1.menuLiteBgColor='#ffffff';
  mm_menu_1019113855_1.menuBorderBgColor='#555555'
  mm_menu_1019113855_1.bgColor='#000000';

  window.mm_menu_1019114044_2 = new Menu("root",157,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  mm_menu_1019114044_2.addMenuItem("Analog&nbsp;&amp;&nbsp;Mixed&nbsp;Signal&nbsp;ICs","location='http://www.st.com/stonline/products/families/analog_and_mixed_signal/analog_and_mixed_signal.htm'");
 mm_menu_1019114044_2.addMenuItem("Memories","location='http://www.st.com/stonline/products/families/memories/memory/index.htm'");
 mm_menu_1019114044_2.addMenuItem("Microcontrollers","location='#'");
 mm_menu_1019114044_2.addMenuItem("Power&nbsp;Management&nbsp;ICs","location='http://www.st.com/stonline/products/families/power_management/power_management.htm'");
  mm_menu_1019114044_2.addMenuItem("Transistors","location='http://www.st.com/stonline/products/families/transistors/transistors.htm'");
  mm_menu_1019114044_2.addMenuItem("ASSP&nbsp;for&nbsp;Audio","location='http://www.st.com/stonline/products/families/audio/audio.htm'");
  mm_menu_1019114044_2.addMenuItem("ASSP&nbsp;for&nbsp;Home&nbsp;Video","location='http://www.st.com/stonline/products/families/homevideo/homevideo.htm'");
  mm_menu_1019114044_2.addMenuItem("ASSP&nbsp;for&nbsp;Mobile&nbsp;Systems","location='http://www.st.com/stonline/products/families/mobile/mobile.htm'");
  mm_menu_1019114044_2.addMenuItem("Product&nbsp;Technologies","location='#'");
  mm_menu_1019114044_2.addMenuItem("See&nbsp;All","location='http://www.st.com/stonline/domains/products/index.htm'");
   mm_menu_1019114044_2.hideOnMouseOut=true;
   mm_menu_1019114044_2.menuBorder=1;
   mm_menu_1019114044_2.menuLiteBgColor='#ffffff'
   mm_menu_1019114044_2.menuBorderBgColor='#555555';
   mm_menu_1019114044_2.bgColor='#000000';

  window.mm_menu_1019114122_3 = new Menu("root",142,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  mm_menu_1019114122_3.addMenuItem("Automotive","location='http://www.st.com/stonline/domains/applications/automotive/index.htm'");
  mm_menu_1019114122_3.addMenuItem("Communications","location='http://www.st.com/stonline/domains/applications/communication/index.htm'");
  mm_menu_1019114122_3.addMenuItem("Computer&nbsp;&amp;&nbsp;Peripherals","location='http://www.st.com/stonline/domains/applications/computer/index.htm'");
  mm_menu_1019114122_3.addMenuItem("Consumer","location='http://www.st.com/stonline/domains/applications/consumer/index.htm'");
  mm_menu_1019114122_3.addMenuItem("Industrial","location='http://www.st.com/stonline/domains/applications/industrial/index.htm'");
  mm_menu_1019114122_3.addMenuItem("Smartcard&nbsp;&amp;&nbsp;Security","location='http://www.st.com/stonline/domains/applications/security/index.htm'");
  mm_menu_1019114122_3.addMenuItem("See&nbsp;All","location='http://www.st.com/stonline/domains/applications/indexapplication.htm'");
   mm_menu_1019114122_3.hideOnMouseOut=true;
   mm_menu_1019114122_3.menuBorder=1;
   mm_menu_1019114122_3.menuLiteBgColor='#ffffff';
   mm_menu_1019114122_3.menuBorderBgColor='#555555';
   mm_menu_1019114122_3.bgColor='#000000';

  window.mm_menu_1019114152_4 = new Menu("root",190,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  mm_menu_1019114152_4.addMenuItem("Technical&nbsp;Support","location='http://www.st.com/stonline/domains/support/contact_support.htm'");
  mm_menu_1019114152_4.addMenuItem("Sales&nbsp;Support","location='http://www.st.com/stonline/domains/support/contact_sales.htm'");
  mm_menu_1019114152_4.addMenuItem("Evaluation&nbsp;Boards","location='http://www.st.com/stonline/stappl/productcatalog/app?path=/comp/stcom/PcStComRPNTableView.onClickFromProductTree&primaryheader=DEVELOPMENT%20TOOLS&secondaryheader=EVALUATION%20TOOLS&subclassheader=Evaluation/demo%20board&subclassid=726.0&count=10&producttype=&date=Fri%20Jan%2013%2014%3A29%3A20%20UTC%2B0100%202006'");
  mm_menu_1019114152_4.addMenuItem("Simulation&nbsp;&amp;&nbsp;Tools","location='http://www.st.com/stonline/domains/support/simulators_tools.htm'");
  mm_menu_1019114152_4.addMenuItem("Technical&nbsp;Literature","location='http://www.st.com/stonline/stappl/productcatalog/app?page=stcom/PcStComTlMainMenu'");
  mm_menu_1019114152_4.addMenuItem("Training&nbsp;&amp;&nbsp;Webseminars","location='http://www.st.com/stonline/domains/support/training.htm'");
  mm_menu_1019114152_4.addMenuItem("Packaging&nbsp;Information","location='http://www.st.com/stonline/stappl/productcatalog/app?path=/pages/stcom/PcStComTlHome.myComboChange&keyword=&ptype=PI&new=false'");
  mm_menu_1019114152_4.addMenuItem("Quality&nbsp;Information","location='http://www.st.com/stonline/company/quality/index.htm'");
  mm_menu_1019114152_4.addMenuItem("RoHS","location='http://www.st.com/stonline/leadfree/index.htm'");
  mm_menu_1019114152_4.hideOnMouseOut=true;
  mm_menu_1019114152_4.menuBorder=1;
  mm_menu_1019114152_4.menuLiteBgColor='#ffffff';
  mm_menu_1019114152_4.menuBorderBgColor='#555555';
  mm_menu_1019114152_4.bgColor='#000000';

  window.mm_menu_1019114221_5 = new Menu("root",190,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  mm_menu_1019114221_5.addMenuItem("Buy&nbsp;ST&nbsp;Parts&nbsp;From&nbsp;Distributors","location='http://www.st.com/stonline/domains/buy/buyindex3.htm'");
  mm_menu_1019114221_5.addMenuItem("Order&nbsp;Free&nbsp;Samples","location='http://www.st.com/stonline/domains/buy/samples/index.htm'");
  mm_menu_1019114221_5.addMenuItem("Buy&nbsp;Development&nbsp;Boards&nbsp;&amp;&nbsp;Tools","location='http://www.st.com/stonline/domains/buy/buy_dev.htm'");
  mm_menu_1019114221_5.addMenuItem("ST&nbsp;Sales&nbsp;Offices","location='http://www.st.com/stonline/address/offices/index.htm'");
  mm_menu_1019114221_5.addMenuItem("Distributors&nbsp;&amp;&nbsp;Representatives", "location='http://www.st.com/stonline/address/distrib/index.htm'");
  mm_menu_1019114221_5.hideOnMouseOut=true;
  mm_menu_1019114221_5.menuBorder=1;
  mm_menu_1019114221_5.menuLiteBgColor='#ffffff';
  mm_menu_1019114221_5.menuBorderBgColor='#555555';
  mm_menu_1019114221_5.bgColor='#000000';

  window.mm_menu_0208104402_6 = new Menu("root",150,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  mm_menu_0208104402_6.addMenuItem("Latest&nbsp;News","location='http://www.st.com/stonline/press/news/latest.htm'");
  mm_menu_0208104402_6.addMenuItem("Corporate&nbsp;Press&nbsp;Releases","location='http://www.st.com/stonline/press/news/corporate.htm'");
  mm_menu_0208104402_6.addMenuItem("Product&nbsp;Press&nbsp;Releases","location='http://www.st.com/stonline/press/news/technical.htm'");
  mm_menu_0208104402_6.addMenuItem("Conferences","location='http://www.st.com/stonline/company/conf/conf.htm'");
  mm_menu_0208104402_6.addMenuItem("Trade&nbsp;Shows","location='http://www.st.com/stonline/company/expo/expo.htm'");
  mm_menu_0208104402_6.hideOnMouseOut=true;
  mm_menu_0208104402_6.menuBorder=1;
  mm_menu_0208104402_6.menuLiteBgColor='#ffffff';
  mm_menu_0208104402_6.menuBorderBgColor='#555555';
  mm_menu_0208104402_6.bgColor='#000000';

  window.mm_menu_0208104916_7 = new Menu("root",90,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  mm_menu_0208104916_7.addMenuItem("&#20013;&#22269;","location='http://www.stmicroelectronics.com.cn/'");
  mm_menu_0208104916_7.addMenuItem("&#26085;&#26412;","location='http://www.st-japan.co.jp/'");
  mm_menu_0208104916_7.addMenuItem("   France","location='http://fr.st.com/'");
  mm_menu_0208104916_7.addMenuItem("   Italia","location='http://it.st.com/'");
  mm_menu_0208104916_7.hideOnMouseOut=true;
  mm_menu_0208104916_7.menuBorder=1;
  mm_menu_0208104916_7.menuLiteBgColor='#ffffff';
  mm_menu_0208104916_7.menuBorderBgColor='#555555'
  mm_menu_0208104916_7.bgColor='#000000';

  // * G. Nicola / ZEROPIU, 04 Feb 08
  // * Changed Menu width from 78 to 100
  window.mm_menu_0208105010_8 = new Menu("root",100,16,"Verdana, Arial, Helvetica, sans-serif",10,"#000000","#ffffff","#e1e1e1","#4169e1","left","middle",3,0,1000,0,0,true,true,true,0,true,true);
  //lx_origURL set to Your Account MCU modules by D.Delseny Capgemini 08/2007
  // * Changed from "Register" to "Register / Login" 
  mm_menu_0208105010_8.addMenuItem("Register&nbsp;/&nbsp;Login","location=' http://www.st.com/stonline/stappl/mvdb/app?page=login&lx_origURL=http://www.st.com/mcu/modules.php?name=Your_Account'");
  mm_menu_0208105010_8.addMenuItem("Private&nbsp;site","location='https://stpartner.st.com/'");
  //following line has been removed by D.Delseny Capgemini 08/2007
  //mm_menu_0208105010_8.addMenuItem(" Account","location='modules.php?name=Your_Account'");
  mm_menu_0208105010_8.hideOnMouseOut=true;
  mm_menu_0208105010_8.menuBorder=1;
  mm_menu_0208105010_8.menuLiteBgColor='#ffffff';
  mm_menu_0208105010_8.menuBorderBgColor='#555555';
  mm_menu_0208105010_8.bgColor='#000000';

  mm_menu_0208105010_8.writeMenus();
} // mmLoadMenus()

